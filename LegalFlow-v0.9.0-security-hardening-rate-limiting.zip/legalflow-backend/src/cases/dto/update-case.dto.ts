import { PartialType } from '@nestjs/mapped-types';
import { CreateCaseDto } from './create-case.dto';
import { IsOptional, IsString } from 'class-validator';

export class UpdateCaseDto extends PartialType(CreateCaseDto) {
  @IsString()
  @IsOptional()
  assignedToId?: string;
}
